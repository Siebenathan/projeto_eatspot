import styles from "./ProfileConfiguration.module.css";
import InputWithLabelInside from "../../forms/inputs/InputWithLabelInside";
import SelectWithSearch from "../../forms/selects/SelectWithSearch";
import { useState, useEffect } from "react";

interface ProfileConfigurationProps {
  username: string;
  nations: any;
}

export default function ProfileConfigurationPage(
  props: ProfileConfigurationProps
) {
  const [changeUsername, setChangeUsername] = useState<string>("");
  const [selectedNation, setSelectedNation] = useState<string>("");

  return (
    <div className={styles.mainDiv}>
      <div className={styles.divGreetings}>
          <h1>
            Edite sua conta <span>{props.username}</span>
          </h1>
          <p>Preencha o formulário abaixo e mude suas informações</p>
      </div>
      <form className={styles.formInputsToEdit}>
        <div className={styles.formRow}>
          <InputWithLabelInside
            labelText="Nome de usuário"
            nameAndId="username"
            value={changeUsername}
            setValue={setChangeUsername}
            type="text"
            required
          />
            <SelectWithSearch
            labelText="Nacionalidade" 
            options={props.nations}
            value={selectedNation}
            setValue={setSelectedNation}
          />
        </div>
        <div className={styles.formRow}></div>
        <div className={styles.formRow}></div>
      </form>
    </div>
  );
}

import styles from "./UserConfigurationPage.module.css";
import Container from "../../layout/Container";
import { useLocation } from "react-router-dom";
import { useState, useEffect } from "react";
import { getDataFromCollection } from "../../services/firebase/firebaseFirestore";
import { getImageStorage } from "../../services/firebase/firebaseStorage";
import defaultUserPhoto from "../../../img/EatSpot-semfundo.png";
import { FaUser, FaCog } from "react-icons/fa";
import { IoIosExit } from "react-icons/io";
import ProfileConfigurationPage from "./ProfileConfiguration";
import { isPropertySignature } from "typescript";

export default function UserConfigurationPage() {
  const [userData, setUserData] = useState<any>();
  const [listNations, setListNations] = useState<any>();
  const [userPhoto, setUserPhoto] = useState<any>();
  const [currentActive, setCurrentActive] = useState<string>("Usuario");
  const location = useLocation();
  const userId = location.state?.userId;

  useEffect(() => {
    getDataFromCollection("users", "userId", userId).then(async (data) => {
      const userDataFirestore: any = data.docs.map((doc) => ({
        ...doc.data(),
        id: doc.id,
      }))[0];
      setUserData(userDataFirestore);
      setUserPhoto(await getUserPhoto(userDataFirestore.userPhotoUrl));
    });

    fetch("https://restcountries.com/v3.1/all")
    .then((response) => response.json())
    .then((data) => {
      data.sort((a: any, b: any) => {
        const nomeA = a.name.common;
        const nomeB = b.name.common;

        if (nomeA < nomeB) {
          return -1;
        }
        if (nomeA > nomeB) {
          return 1;
        }

        return 0;
      });
      const contryNames: string[] = [];
      data.forEach((country: any) => {
        contryNames.push(country.name.common);
      });
      setListNations(contryNames);
    })
    .catch((err) => console.log(err));
  }, []);

  async function getUserPhoto(imageUrl: string) {
    let userPhoto: any = null;
    userPhoto = await getImageStorage(imageUrl);
    if (userPhoto == "erro imagem nao encontrada") {
      userPhoto = defaultUserPhoto;
    }
    return userPhoto;
  }

  return (
    <Container
      customClass={"flexForUserConfigurationPage"}
      styleContainer={{
        padding: "100px 0px 0px 0px",
      }}
    >
      {userData && (
        <>
          <div className={styles.navigation}>
            <ul>
              <li
                className={`${styles.list} ${
                  currentActive == "Usuario" ? styles.active : ""
                }`}
              >
                <button
                  onClick={() => {
                    setCurrentActive("Usuario");
                  }}
                >
                  <span className={styles.icon}>
                    <FaUser className={styles.faIcons} />
                  </span>
                  <span className={styles.title}>Usuario</span>
                </button>
              </li>
              <li
                className={`${styles.list} ${
                  currentActive == "Configurações" ? styles.active : ""
                }`}
              >
                <button
                  onClick={() => {
                    setCurrentActive("Configurações");
                  }}
                >
                  <span className={styles.icon}>
                    <FaCog className={styles.faIcons} />
                  </span>
                  <span className={styles.title}>Configurações</span>
                </button>
              </li>
              <li
                className={`${styles.list} ${
                  currentActive == "Sair" ? styles.active : ""
                }`}
              >
                <button
                  onClick={() => {
                    setCurrentActive("Sair");
                  }}
                >
                  <span className={styles.icon}>
                    <IoIosExit className={styles.exitIcon} />
                  </span>
                  <span className={styles.title}>Sair</span>
                </button>
              </li>
            </ul>
          </div>
          <div className={styles.divContent}>
            {currentActive == "Usuario" && (
              <ProfileConfigurationPage username={userData.name} nations={listNations ?? []} />
            )}
          </div>
        </>
      )}
    </Container>
  );
}
